#!/bin/bash

export PATH="$FSROOT/bin:$PATH"
export DYLD_LIBRARY_PATH="$FSROOT/lib:$DYLD_LIBRARY_PATH"
