#ifndef JOIN_DEBUG_H
#define JOIN_DEBUG_H

//#define DEBUG_MERGE 1
//#define DEBUG_FILTER 1
//#define DEBUG_COMPARE 1
//#define DEBUG_OPTIMISER 1
//#define DEBUG_ORDER 1
//#define DEBUG_BINDING "ac"

#endif
