#ifndef DISK_SPACE_H
#define DISK_SPACE_H

float fs_free_disk(const char *kb);

#endif
