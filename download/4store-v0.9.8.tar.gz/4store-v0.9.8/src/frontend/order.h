#ifndef ORDER_H
#define ORDER_H

#include "query-datatypes.h"

void fs_query_order(fs_query *q);

#endif
